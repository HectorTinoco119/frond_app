/* ================== CONFIG API BASE ================== */
/* 
   Cambia USE_LAN:
   - true  -> usa 192.168.1.58:4000
   - false -> usa localhost:4000
*/
const USE_LAN = true;
const API_HOST = USE_LAN ? "192.168.1.58" : "localhost";
const API_BASE = `http://${API_HOST}:4000`;

/* --- Función para mostrar alertas Bootstrap --- */
function showAlert(message, type = "info") {
  const container = document.getElementById("alertContainer");
  if (!container) return;
  container.innerHTML = `
    <div class="alert alert-${type} alert-dismissible fade show" role="alert">
      ${message}
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  `;
}

/* --- Helper: obtener rol desde el token JWT (payload.role) --- */
function getRoleFromToken(token) {
  try {
    const payloadBase64 = token.split(".")[1];
    const payloadJson = atob(payloadBase64);
    const payload = JSON.parse(payloadJson);
    let role = payload.role || null;

    if (role === "ROLE_ADMIN") role = "ADMIN";
    if (role === "ROLE_OPERADOR") role = "OPERADOR";

    return role;
  } catch (error) {
    console.error("No se pudo obtener el rol desde el token", error);
    return null;
  }
}

/* ===================================================== */
/* ================== REGISTRO ========================= */
/* ===================================================== */
async function register() {
  const data = {
    email: document.getElementById("regEmail").value,
    password: document.getElementById("regPassword").value,
    firstname: document.getElementById("regFirstname").value,
    lastname: document.getElementById("regLastname").value,
    country: document.getElementById("regCountry").value,
    role: document.getElementById("regRole").value
  };

  try {
    const res = await fetch(`${API_BASE}/api/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });

    if (res.ok) {
      showAlert("Usuario registrado correctamente ✅", "success");
    } else {
      showAlert("Error al registrar el usuario ❌", "danger");
    }
  } catch (error) {
    console.error("Error de conexión en registro:", error);
    showAlert("Error de conexión con el servidor", "danger");
  }
}

/* ===================================================== */
/* ================== LOGIN ============================ */
/* ===================================================== */
async function login() {
  const data = {
    email: document.getElementById("loginEmail").value,
    password: document.getElementById("loginPassword").value
  };

  try {
    const res = await fetch(`${API_BASE}/api/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });

    if (!res.ok) {
      showAlert("Credenciales incorrectas ❌", "danger");
      return;
    }

    const json = await res.json();

    // Guardar token
    const token = json.token;
    localStorage.setItem("token", token);

    // Determinar rol desde json o token
    let role =
      (json.user && json.user.role) ||
      json.role ||
      getRoleFromToken(token);

    if (role === "ROLE_ADMIN") role = "ADMIN";
    if (role === "ROLE_OPERADOR") role = "OPERADOR";

    // Guardar rol
    localStorage.setItem("role", role);

    showAlert("Inicio de sesión exitoso ✅", "success");

    setTimeout(() => window.location.href = "profile.html", 800);

  } catch (error) {
    console.error("Error de conexión en login:", error);
    showAlert("Error de conexión con el servidor", "danger");
  }
}

/* ===================================================== */
/* ================== PERFIL =========================== */
/* ===================================================== */
async function loadProfile() {
  const token = localStorage.getItem("token");
  if (!token) {
    window.location.href = "index.html";
    return;
  }

  // Obtener rol
  let role = localStorage.getItem("role") || getRoleFromToken(token);

  let profilePath;
  if (role === "OPERADOR") profilePath = "/operador/profile";
  else profilePath = "/admin/profile";

  try {
    const res = await fetch(`${API_BASE}${profilePath}`, {
      headers: { "Authorization": `Bearer ${token}` }
    });

    if (!res.ok) {
      logout();
      return;
    }

    const user = await res.json();
    renderProfile(user);

  } catch (error) {
    console.error("Error al cargar el perfil:", error);
    logout();
  }
}

/* --- Renderizar los datos del perfil --- */
function renderProfile(user) {
  const container = document.getElementById("profileContainer");
  if (!container) return;

  container.innerHTML = `
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-body">
          <h4 class="mb-3 text-center">${user.firstname} ${user.lastname}</h4>
          <ul class="list-group">
            <li class="list-group-item"><strong>ID:</strong> ${user.id}</li>
            <li class="list-group-item"><strong>Correo:</strong> ${user.email}</li>
            <li class="list-group-item"><strong>País:</strong> ${user.country}</li>
            <li class="list-group-item"><strong>Rol:</strong> ${user.role}</li>
            <li class="list-group-item"><strong>Estado:</strong> ${user.enabled ? "Activo" : "Inactivo"}</li>
          </ul>
        </div>
      </div>
    </div>
  `;
}

/* ===================================================== */
/* ================== LOGOUT =========================== */
/* ===================================================== */
function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("role");
  window.location.href = "index.html";
}

/* ===================================================== */
/* ===== Autoejecución: si estoy en profile.html ======= */
/* ===================================================== */
if (window.location.pathname.endsWith("profile.html")) {
  loadProfile();
}
