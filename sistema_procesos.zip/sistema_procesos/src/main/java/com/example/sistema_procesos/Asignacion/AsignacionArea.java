package com.example.sistema_procesos.Asignacion;

public enum AsignacionArea {
    ALIMENTOS_BASICOS,
    PRODUCTOS_LIMPIEZA,
    HIGIENE_PERSONAL
}
