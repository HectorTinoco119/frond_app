package com.example.sistema_procesos.User;

public enum Role {
    ROLE_ADMIN,
    ROLE_OPERADOR
}