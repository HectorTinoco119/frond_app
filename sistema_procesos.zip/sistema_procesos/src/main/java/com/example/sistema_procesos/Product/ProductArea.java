package com.example.sistema_procesos.Product;

public enum ProductArea {
    ALIMENTOS_BASICOS,
    PRODUCTOS_LIMPIEZA,
    HIGIENE_PERSONAL
}
